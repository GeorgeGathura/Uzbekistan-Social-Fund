-- Adminer 4.8.1 PostgreSQL 12.9 (Debian 12.9-1.pgdg110+1) dump

-- 2022-02-15 12:33:29.226702+00
